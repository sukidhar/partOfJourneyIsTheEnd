//
//  UserCell.swift
//  iOS-3MP
//
//  Created by ingenuo-yag on 27/05/20.
//  Copyright © 2020 Sukidhar Darisi. All rights reserved.
//

import UIKit
import Firebase
import FirebaseDatabase
import KeychainSwift

class UserCell: UITableViewCell{
    
    let keychain = DataService().keyChain
    let db = Firestore.firestore()
    var message: Message?{
        didSet{
            setupNameAndProfileImage()
            self.detailTextLabel?.text = message?.content
        }
    }
    
    private func setupNameAndProfileImage(){
        
        if let id = message?.chatPartnerId() {
            let collectionRef = db.collection("USER").whereField("id", isEqualTo: id)
                          collectionRef.getDocuments { (querySnapshot, err) in
                              if let docs = querySnapshot?.documents {
                                  for docSnapshot in docs {
                                      defer{
                                       self.textLabel?.text = docSnapshot.data()["name"] as? String
                                      }
                                   }
                              }
                   }
//            let ref = Database.database().reference().child("USER").child(id)
//            ref.observe(.value) { (snapshot) in
//                if let dictionary = snapshot.value as? [String:AnyObject]
//                {
//                    self.textLabel?.text = dictionary["name"] as? String
//                }
//            }
        }
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        textLabel?.frame = CGRect(x: 64, y: textLabel!.frame.origin.y - 2, width: textLabel!.frame.width, height: textLabel!.frame.height)
        detailTextLabel?.frame = CGRect(x: 64, y: detailTextLabel!.frame.origin.y + 2, width: detailTextLabel!.frame.width, height: detailTextLabel!.frame.height)
    }
    
    let profileImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.image = UIImage(named: "default")
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.layer.cornerRadius = 24
        imageView.layer.masksToBounds = true
        return imageView
    }()
    
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: .subtitle, reuseIdentifier: reuseIdentifier)
        addSubview(profileImageView)
        
        profileImageView.leftAnchor.constraint(equalTo: self.leftAnchor, constant: 8).isActive = true
        
        profileImageView.centerYAnchor.constraint(equalTo: self.centerYAnchor).isActive = true
        profileImageView.widthAnchor.constraint(equalToConstant: 48).isActive = true
        profileImageView.heightAnchor.constraint(equalToConstant: 48).isActive = true
        

        
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

