//
//  UniversityCollectionViewCell.swift
//  iOS-3MP
//
//  Created by Sukidhar Darisi on 24/05/20.
//  Copyright © 2020 Sukidhar Darisi. All rights reserved.
//

import UIKit

class UniversityCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var enclosingView: UIView!
    @IBOutlet weak var starButton: UIButton!
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        let height = imageView.frame.height
        imageView.round(corners: [.topRight, .bottomLeft], cornerRadius: Double((height)/3))
        enclosingView.clipsToBounds = true
        enclosingView.layer.masksToBounds = true
        
    }
    

}
