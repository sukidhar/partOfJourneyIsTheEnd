//
//  favUniStruct.swift
//  iOS-3MP
//
//  Created by Sukidhar Darisi on 19/05/20.
//  Copyright © 2020 Sukidhar Darisi. All rights reserved.
//


import UIKit
import Firebase
import KeychainSwift

struct globalValues {
    static var universties = [String]()
    static var data = Dictionary<String, Any>()
    static var dateOfBirth = Timestamp()
    
}


