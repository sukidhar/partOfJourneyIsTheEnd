//
//  PostModel.swift
//  iOS-3MP
//
//  Created by ingenuo-yag on 23/05/20.
//  Copyright © 2020 Sukidhar Darisi. All rights reserved.
//

import Foundation
import UIKit


struct PostModel {
    let content: String
    let title : String
    let userId : String
    let universityID: String
}
