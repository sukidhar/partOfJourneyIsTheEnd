//
//  Message.swift
//  iOS-3MP
//
//  Created by ingenuo-yag on 27/05/20.
//  Copyright © 2020 Sukidhar Darisi. All rights reserved.
//

import UIKit
import KeychainSwift
class Message: NSObject {
    
    var keychain = DataService().keyChain
    var receiverId: String?
    var senderId: String?
    //var timestamp: NSNumber?
    var content: String?
    
    func chatPartnerId() -> String? {
        if senderId == keychain.get("uid") {
            return receiverId
        } else {
            return senderId
        }
    }
}
